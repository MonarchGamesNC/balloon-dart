#pragma once

void f1();
