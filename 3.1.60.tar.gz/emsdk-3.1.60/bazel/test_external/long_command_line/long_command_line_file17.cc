#include "long_command_line_file17.hh"

#include <iostream>

void f17() { std::cout << "hello from f17()\n"; }
