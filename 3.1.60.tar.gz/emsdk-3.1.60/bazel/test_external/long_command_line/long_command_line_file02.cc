#include "long_command_line_file02.hh"

#include <iostream>

void f2() { std::cout << "hello from f2()\n"; }
